#pragma once

#include "Framework.h"
#pragma comment(lib, "../Debug/Framework.lib")